#pragma once
#include <string>

namespace hz {

    void ApplyTextureTo(const std::string& shapeName, const std::string& texturePath);

}