// Load.h
#pragma once

namespace hz {
    void ShowLoadingScreen(); // Call this before the first frame
}