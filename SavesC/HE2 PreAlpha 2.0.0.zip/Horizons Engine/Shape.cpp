// Shape.cpp
#include <windows.h>  // Needed before gl.h on Windows
#include <GL/gl.h>
#include <cmath>

namespace hz {

    // ---------- TRIANGLE ----------
    static const float triangleVerts[] = {
        0.0f,  0.5f, 0.0f,  // top
       -0.5f, -0.5f, 0.0f,  // bottom left
        0.5f, -0.5f, 0.0f   // bottom right
    };

    static const GLuint triangleIndices[] = { 0, 1, 2 };

    void DrawTriangle() {
        glBegin(GL_TRIANGLES);
        for (int i = 0; i < 3; ++i) {
            glVertex3f(
                triangleVerts[triangleIndices[i] * 3 + 0],
                triangleVerts[triangleIndices[i] * 3 + 1],
                triangleVerts[triangleIndices[i] * 3 + 2]
            );
        }
        glEnd();
    }

    // ---------- PLANE (square) ----------
    static const float planeVerts[] = {
       -0.5f, 0.0f, -0.5f, // 0
        0.5f, 0.0f, -0.5f, // 1
        0.5f, 0.0f,  0.5f, // 2
       -0.5f, 0.0f,  0.5f  // 3
    };

    static const GLuint planeIndices[] = {
        0, 1, 2,
        0, 2, 3
    };

    void DrawPlane() {
        glBegin(GL_TRIANGLES);
        for (int i = 0; i < 6; ++i) {
            glVertex3f(
                planeVerts[planeIndices[i] * 3 + 0],
                planeVerts[planeIndices[i] * 3 + 1],
                planeVerts[planeIndices[i] * 3 + 2]
            );
        }
        glEnd();
    }

    // ---------- CIRCLE ----------
    static const int circleSegments = 32;
    static float circleVerts[(circleSegments + 1) * 3]; // x,y,z

    void InitCircle() {
        circleVerts[0] = 0.0f; // center x
        circleVerts[1] = 0.0f; // center y
        circleVerts[2] = 0.0f; // center z
        for (int i = 0; i <= circleSegments; ++i) {
            float angle = 2.0f * 3.14159265359f * i / circleSegments;
            circleVerts[(i + 1) * 3 + 0] = cosf(angle) * 0.5f;
            circleVerts[(i + 1) * 3 + 1] = 0.0f;
            circleVerts[(i + 1) * 3 + 2] = sinf(angle) * 0.5f;
        }
    }

    void DrawCircle() {
        glBegin(GL_TRIANGLE_FAN);
        for (int i = 0; i <= circleSegments + 1; ++i) {
            int idx = i % (circleSegments + 1);
            glVertex3f(
                circleVerts[idx * 3 + 0],
                circleVerts[idx * 3 + 1],
                circleVerts[idx * 3 + 2]
            );
        }
        glEnd();
    }

    // ---------- CUBE ----------
    static const float cubeVerts[] = {
       -0.5f, -0.5f, -0.5f,  // 0
        0.5f, -0.5f, -0.5f,  // 1
        0.5f,  0.5f, -0.5f,  // 2
       -0.5f,  0.5f, -0.5f,  // 3
       -0.5f, -0.5f,  0.5f,  // 4
        0.5f, -0.5f,  0.5f,  // 5
        0.5f,  0.5f,  0.5f,  // 6
       -0.5f,  0.5f,  0.5f   // 7
    };

    static const GLuint cubeIndices[] = {
        4, 5, 6, 4, 6, 7, // front
        0, 3, 2, 0, 2, 1, // back
        0, 4, 7, 0, 7, 3, // left
        1, 2, 6, 1, 6, 5, // right
        3, 7, 6, 3, 6, 2, // top
        0, 1, 5, 0, 5, 4  // bottom
    };

    void DrawCube() {
        glBegin(GL_TRIANGLES);
        for (int i = 0; i < 36; ++i) {
            glVertex3f(
                cubeVerts[cubeIndices[i] * 3 + 0],
                cubeVerts[cubeIndices[i] * 3 + 1],
                cubeVerts[cubeIndices[i] * 3 + 2]
            );
        }
        glEnd();
    }

    // ---------- PYRAMID (square base) ----------
    static const float pyramidVerts[] = {
       -0.5f, 0.0f, -0.5f,  // base 0
        0.5f, 0.0f, -0.5f,  // base 1
        0.5f, 0.0f,  0.5f,  // base 2
       -0.5f, 0.0f,  0.5f,  // base 3
        0.0f, 1.0f,  0.0f   // apex 4
    };

    static const GLuint pyramidIndices[] = {
        // base
        0, 1, 2,
        0, 2, 3,
        // sides
        0, 1, 4,
        1, 2, 4,
        2, 3, 4,
        3, 0, 4
    };

    void DrawPyramid() {
        glBegin(GL_TRIANGLES);
        for (int i = 0; i < 18; ++i) {
            glVertex3f(
                pyramidVerts[pyramidIndices[i] * 3 + 0],
                pyramidVerts[pyramidIndices[i] * 3 + 1],
                pyramidVerts[pyramidIndices[i] * 3 + 2]
            );
        }
        glEnd();
    }

    // ---------- PRISM (triangular base) ----------
    static const float prismVerts[] = {
        // base triangle bottom
       -0.5f, 0.0f, -0.5f,  // 0
        0.5f, 0.0f, -0.5f,  // 1
        0.0f, 0.0f,  0.5f,  // 2
        // same triangle top
       -0.5f, 1.0f, -0.5f,  // 3
        0.5f, 1.0f, -0.5f,  // 4
        0.0f, 1.0f,  0.5f   // 5
    };

    static const GLuint prismIndices[] = {
        // bottom face
        0, 1, 2,
        // top face
        3, 5, 4,
        // sides
        0, 3, 1,
        1, 3, 4,
        1, 4, 2,
        2, 4, 5,
        2, 5, 0,
        0, 5, 3
    };

    void DrawPrism() {
        glBegin(GL_TRIANGLES);
        for (int i = 0; i < 24; ++i) {
            glVertex3f(
                prismVerts[prismIndices[i] * 3 + 0],
                prismVerts[prismIndices[i] * 3 + 1],
                prismVerts[prismIndices[i] * 3 + 2]
            );
        }
        glEnd();
    }

    // ---------- SPHERE ----------
    // We'll generate a UV sphere dynamically for simplicity
    void DrawSphere(int slices = 16, int stacks = 16) {
        for (int i = 0; i < stacks; ++i) {
            float lat0 = 3.14159265359f * (-0.5f + (float)(i) / stacks);
            float z0 = sinf(lat0);
            float zr0 = cosf(lat0);

            float lat1 = 3.14159265359f * (-0.5f + (float)(i + 1) / stacks);
            float z1 = sinf(lat1);
            float zr1 = cosf(lat1);

            glBegin(GL_QUAD_STRIP);
            for (int j = 0; j <= slices; ++j) {
                float lng = 2 * 3.14159265359f * (float)(j) / slices;
                float x = cosf(lng);
                float y = sinf(lng);

                glVertex3f(x * zr0 * 0.5f, y * zr0 * 0.5f, z0 * 0.5f);
                glVertex3f(x * zr1 * 0.5f, y * zr1 * 0.5f, z1 * 0.5f);
            }
            glEnd();
        }
    }

    // ---------- CONE ----------
    void DrawCone(int slices = 32, float height = 1.0f, float radius = 0.5f) {
        // Draw base circle
        glBegin(GL_TRIANGLE_FAN);
        glVertex3f(0, 0, 0); // center base
        for (int i = 0; i <= slices; ++i) {
            float angle = 2.0f * 3.14159265359f * i / slices;
            float x = cosf(angle) * radius;
            float z = sinf(angle) * radius;
            glVertex3f(x, 0, z);
        }
        glEnd();

        // Draw side triangles
        glBegin(GL_TRIANGLES);
        for (int i = 0; i < slices; ++i) {
            float angle0 = 2.0f * 3.14159265359f * i / slices;
            float angle1 = 2.0f * 3.14159265359f * (i + 1) / slices;

            float x0 = cosf(angle0) * radius;
            float z0 = sinf(angle0) * radius;
            float x1 = cosf(angle1) * radius;
            float z1 = sinf(angle1) * radius;

            glVertex3f(x0, 0, z0);
            glVertex3f(x1, 0, z1);
            glVertex3f(0, height, 0);
        }
        glEnd();
    }

    // ---------- CYLINDER ----------
    void DrawCylinder(int slices = 32, float height = 1.0f, float radius = 0.5f) {
        // Draw bottom circle
        glBegin(GL_TRIANGLE_FAN);
        glVertex3f(0, 0, 0);
        for (int i = 0; i <= slices; ++i) {
            float angle = 2.0f * 3.14159265359f * i / slices;
            float x = cosf(angle) * radius;
            float z = sinf(angle) * radius;
            glVertex3f(x, 0, z);
        }
        glEnd();

        // Draw top circle
        glBegin(GL_TRIANGLE_FAN);
        glVertex3f(0, height, 0);
        for (int i = 0; i <= slices; ++i) {
            float angle = 2.0f * 3.14159265359f * i / slices;
            float x = cosf(angle) * radius;
            float z = sinf(angle) * radius;
            glVertex3f(x, height, z);
        }
        glEnd();

        // Draw side quads
        glBegin(GL_QUAD_STRIP);
        for (int i = 0; i <= slices; ++i) {
            float angle = 2.0f * 3.14159265359f * i / slices;
            float x = cosf(angle) * radius;
            float z = sinf(angle) * radius;
            glVertex3f(x, 0, z);
            glVertex3f(x, height, z);
        }
        glEnd();
    }

} // namespace hz
