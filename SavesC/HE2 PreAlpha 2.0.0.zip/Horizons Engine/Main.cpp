// main.cpp
#include <windows.h>
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <gl/GL.h>
#include <gl/GLU.h>

#include "Frame.h"
#include "Shape.h"
#include "ShapeX.h"
#include "NewShape.h"

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")

    // Get the primary monitor size
int windowWidth = GetSystemMetrics(SM_CXSCREEN);
int windowHeight = GetSystemMetrics(SM_CYSCREEN);

float eyeX = 0.0f, eyeY = 0.0f, eyeZ = 5.0f;      // Camera position
float centerX = 0.0f, centerY = 0.0f, centerZ = 0.0f;  // Look at origin
float upX = 0.0f, upY = 1.0f, upZ = 0.0f;         // Up vector
float aspectRatio = (float)windowWidth / (float)windowHeight;

float camSpeed = 0.1f;

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

void SetupPixelFormat(HDC hdc) {
    PIXELFORMATDESCRIPTOR pfd = { 0 };
    pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 32;
    pfd.cDepthBits = 24;
    pfd.iLayerType = PFD_MAIN_PLANE;

    int pf = ChoosePixelFormat(hdc, &pfd);
    if (pf == 0) {
        MessageBox(NULL, "ChoosePixelFormat failed.", "Error", MB_OK);
        exit(1);
    }
    if (!SetPixelFormat(hdc, pf, &pfd)) {
        MessageBox(NULL, "SetPixelFormat failed.", "Error", MB_OK);
        exit(1);
    }
}

void InitScene() {
    hz::InitCircle(); // if you're using circles too
    std::srand(static_cast<unsigned>(std::time(nullptr)));

    // Add initial cube in front of camera at (0,0,-5)
    hz::AddShape(hz::SHAPE_CUBE, 0.0f, 0.0f, -5.0f, 0, 0, 0, 1.0f, 1, 0, 0); // Red cube
}

void UpdateCameraPosition() {
    float forwardX = centerX - eyeX;
    float forwardY = centerY - eyeY;
    float forwardZ = centerZ - eyeZ;
    float length = std::sqrt(forwardX * forwardX + forwardY * forwardY + forwardZ * forwardZ);
    if (length == 0.0f) return;

    // Normalize forward vector
    forwardX /= length;
    forwardY /= length;
    forwardZ /= length;

    // Right vector = forward cross up (Y up)
    float rightX = forwardZ;
    float rightY = 0.0f;
    float rightZ = -forwardX;

    // Move with WASD
    if (GetAsyncKeyState('W') & 0x8000) {
        eyeX += forwardX * camSpeed;
        eyeY += forwardY * camSpeed;
        eyeZ += forwardZ * camSpeed;
        centerX += forwardX * camSpeed;
        centerY += forwardY * camSpeed;
        centerZ += forwardZ * camSpeed;
    }
    if (GetAsyncKeyState('S') & 0x8000) {
        eyeX -= forwardX * camSpeed;
        eyeY -= forwardY * camSpeed;
        eyeZ -= forwardZ * camSpeed;
        centerX -= forwardX * camSpeed;
        centerY -= forwardY * camSpeed;
        centerZ -= forwardZ * camSpeed;
    }
    if (GetAsyncKeyState('A') & 0x8000) {
        eyeX += rightX * camSpeed;
        eyeZ += rightZ * camSpeed;
        centerX += rightX * camSpeed;
        centerZ += rightZ * camSpeed;
    }
    if (GetAsyncKeyState('D') & 0x8000) {
        eyeX -= rightX * camSpeed;
        eyeZ -= rightZ * camSpeed;
        centerX -= rightX * camSpeed;
        centerZ -= rightZ * camSpeed;
    }
    // Up/down
    if (GetAsyncKeyState(VK_SPACE) & 0x8000) {
        eyeY += camSpeed;
        centerY += camSpeed;
    }
    if (GetAsyncKeyState(VK_SHIFT) & 0x8000) {
        eyeY -= camSpeed;
        centerY -= camSpeed;
    }
}

void DrawAllShapes() {
    for (const auto& shape : hz::shapes)
        shape.Draw();
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int) {
    const char* CLASS_NAME = "HorizonsEngineClass";

    WNDCLASS wc = { };
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.style = CS_OWNDC; // Important for OpenGL

    RegisterClass(&wc);

    // Create fullscreen window
    HWND hwnd = CreateWindowEx(
        WS_EX_APPWINDOW,
        CLASS_NAME,
        "Horizons Engine",
        WS_POPUP | WS_VISIBLE,
        0, 0, windowWidth, windowHeight,
        NULL, NULL, hInstance, NULL);

    if (!hwnd) {
        MessageBox(NULL, "Failed to create window.", "Error", MB_OK);
        return -1;
    }

    // Get device context and set pixel format
    HDC hdc = GetDC(hwnd);
    SetupPixelFormat(hdc);

    // Create and enable OpenGL rendering context
    HGLRC hglrc = wglCreateContext(hdc);
    if (!hglrc) {
        MessageBox(NULL, "Failed to create OpenGL context.", "Error", MB_OK);
        return -1;
    }
    if (!wglMakeCurrent(hdc, hglrc)) {
        MessageBox(NULL, "Failed to activate OpenGL context.", "Error", MB_OK);
        return -1;
    }

    InitFrameLimiter();

    ShowWindow(hwnd, SW_SHOW);
    SetForegroundWindow(hwnd);
    SetFocus(hwnd);
    InitScene();

    // Main loop
    MSG msg = { };
    bool running = true;
    while (running) {
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) running = false;
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        // OpenGL rendering here:
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);  // Dark blue background
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(45.0, aspectRatio, 0.1, 100.0);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        gluLookAt(eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ);

        // Check if 'N' is pressed
        if (GetAsyncKeyState('N') & 0x8000) {
            float x = static_cast<float>((std::rand() % 11) - 5); // -100 to 100
            float y = static_cast<float>((std::rand() % 11) - 5);
            float z = -300.0f; // Pull it into view
            hz::AddShape(hz::SHAPE_CUBE, x, y, -5.0f, 0, 0, 0, 1.0f, 1, 1, 1); // White cube
            Sleep(150); // Prevent spam adding
        }

        UpdateCameraPosition();

        // Render all shapes
        DrawAllShapes();

        LimitFrame();

        // Swap buffers
        SwapBuffers(hdc);
    }

    // Cleanup
    wglMakeCurrent(NULL, NULL);
    wglDeleteContext(hglrc);
    ReleaseDC(hwnd, hdc);
    DestroyWindow(hwnd);

    return 0;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    case WM_CLOSE:
        PostQuitMessage(0);
        return 0;
    case WM_KEYDOWN:
        if (wParam == VK_ESCAPE) {
            PostQuitMessage(0);
            return 0;
        }
        break;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}
