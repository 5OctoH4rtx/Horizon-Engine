#pragma once

void InitFrameLimiter(double targetFPS = 60.0);
void LimitFrame();
