#include "Frame.h"
#include <windows.h>

static LARGE_INTEGER frequency;
static LARGE_INTEGER frameStart;
static double frameDuration = 1.0 / 60.0; // Default to 60 FPS

void InitFrameLimiter(double targetFPS) {
    QueryPerformanceFrequency(&frequency);
    frameDuration = 1.0 / targetFPS;
    QueryPerformanceCounter(&frameStart);
}

void LimitFrame() {
    LARGE_INTEGER now;
    QueryPerformanceCounter(&now);
    double elapsed = (now.QuadPart - frameStart.QuadPart) / static_cast<double>(frequency.QuadPart);

    while (elapsed < frameDuration) {
        Sleep(0);
        QueryPerformanceCounter(&now);
        elapsed = (now.QuadPart - frameStart.QuadPart) / static_cast<double>(frequency.QuadPart);
    }

    QueryPerformanceCounter(&frameStart);
}
