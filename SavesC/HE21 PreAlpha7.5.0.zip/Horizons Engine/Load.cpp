// Load.cpp
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include "Load.h"
#include "RenText.h" // Assumes you have a RenderTextOnScreen function

    // Get the primary monitor size
int loadWidth = GetSystemMetrics(SM_CXSCREEN);
int loadHeight = GetSystemMetrics(SM_CYSCREEN);

namespace hz {

    void ShowLoadingScreen() {
        // Set up basic black background
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Set up orthographic projection for text rendering
        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        gluOrtho2D(0, loadWidth, loadHeight, 0); // Adjust to your screen dimensions
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();

        // Render "Loading..." in white at screen center
        hz::RenderTextOnScreen("...Loading...", 960, 540, 1.0f, 1.0f, 1.0f, true);

        // Restore matrices
        glPopMatrix();
        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);

        // Swap buffers if needed
        glFlush();
        SwapBuffers(wglGetCurrentDC());
        Sleep(1200); // Sleep for 5000 milliseconds (5 seconds)
    }
}
