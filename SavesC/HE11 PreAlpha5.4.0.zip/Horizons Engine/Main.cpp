﻿// main.cpp
#include <windows.h>
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <limits>
#include <gl/GL.h>
#include <gl/GLU.h>

#include "Frame.h"
#include "Shape.h"
#include "ShapeX.h"
#include "NewShape.h"
#include "Select.h"
#include "SelMove.h"
#include "SelRot.h"
#include "SelScale.h"
#include "SelColor.h"
#include "Cross.h"

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")

    // Get the primary monitor size
int windowWidth = GetSystemMetrics(SM_CXSCREEN);
int windowHeight = GetSystemMetrics(SM_CYSCREEN);

float eyeX = 0.0f, eyeY = 0.0f, eyeZ = 5.0f;      // Camera position
float centerX = 0.0f, centerY = 0.0f, centerZ = 0.0f;  // Look at origin
float upX = 0.0f, upY = 1.0f, upZ = 0.0f;         // Up vector
float aspectRatio = (float)windowWidth / (float)windowHeight;

float camSpeed = 0.1f;

float cameraYaw = -90.0f;    // Horizontal angle, degrees
float cameraPitch = 0.0f;  // Vertical angle, degrees

int MouseUsePosX = 0; //Usable Mouse Position Global Variable X
int MouseUsePosY = 0; //Usable Mouse Position Global Variable Y

bool wasNPressed = false;
bool lmbWasDown = false;    // tracks previous-frame state

bool isVisible = true;

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

void SetupPixelFormat(HDC hdc) {
    PIXELFORMATDESCRIPTOR pfd = { 0 };
    pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 32;
    pfd.cDepthBits = 24;
    pfd.iLayerType = PFD_MAIN_PLANE;

    int pf = ChoosePixelFormat(hdc, &pfd);
    if (pf == 0) {
        MessageBox(NULL, "ChoosePixelFormat failed.", "Error", MB_OK);
        exit(1);
    }
    if (!SetPixelFormat(hdc, pf, &pfd)) {
        MessageBox(NULL, "SetPixelFormat failed.", "Error", MB_OK);
        exit(1);
    }
}

void InitScene() {
    hz::InitCircle(); // if you're using circles too
    std::srand(static_cast<unsigned>(std::time(nullptr)));

    // Add initial cube in front of camera at (0,0,-5)
    hz::AddShape(hz::SHAPE_CUBE, 0.0f, 0.0f, -5.0f, 0, 0, 0, 1.0f, 1, 0, 0); // Red cube
}

void UpdateMouseLook(HWND hwnd) {
    // Get window center point in screen coords
    RECT rect;
    GetClientRect(hwnd, &rect);
    POINT center = { (rect.right - rect.left) / 2, (rect.bottom - rect.top) / 2 };
    ClientToScreen(hwnd, &center);

    // Get current cursor position
    POINT mousePos;
    GetCursorPos(&mousePos);

     MouseUsePosX = mousePos.x;
     MouseUsePosY = mousePos.y;

    // Calculate delta movement
    int dx = mousePos.x - center.x;
    int dy = mousePos.y - center.y;

    const float sensitivity = 0.15f; // Adjust sensitivity here

    cameraYaw += dx * sensitivity;
    cameraPitch -= dy * sensitivity;

    // Clamp pitch to avoid flipping camera
    if (cameraPitch > 89.9f) cameraPitch = 89.9f;
    if (cameraPitch < -89.9f) cameraPitch = -89.9f;

    // Reset cursor to center
    SetCursorPos(center.x, center.y);
}

void UpdateCameraPosition() {
    float forwardX = centerX - eyeX;
    float forwardY = centerY - eyeY;
    float forwardZ = centerZ - eyeZ;
    float length = std::sqrt(forwardX * forwardX + forwardY * forwardY + forwardZ * forwardZ);
    if (length == 0.0f) return;

    // Convert degrees to radians
    float yawRad = cameraYaw * 3.14159265f / 180.0f;
    float pitchRad = cameraPitch * 3.14159265f / 180.0f;

    // Calculate direction vector
    float dirX = cosf(pitchRad) * cosf(yawRad);
    float dirY = sinf(pitchRad);
    float dirZ = cosf(pitchRad) * sinf(yawRad);

    // Camera position stays eyeX, eyeY, eyeZ, but center is eye + direction
    centerX = eyeX + dirX;
    centerY = eyeY + dirY;
    centerZ = eyeZ + dirZ;

    // Normalize forward vector
    forwardX /= length;
    forwardY /= length;
    forwardZ /= length;

    // Right vector = forward cross up (Y up)
    float rightX = forwardZ;
    float rightY = 0.0f;
    float rightZ = -forwardX;

    // Move with WASD
    if (GetAsyncKeyState('W') & 0x8000) {
        eyeX += forwardX * camSpeed;
        eyeY += forwardY * camSpeed;
        eyeZ += forwardZ * camSpeed;
        centerX += forwardX * camSpeed;
        centerY += forwardY * camSpeed;
        centerZ += forwardZ * camSpeed;
    }
    if (GetAsyncKeyState('S') & 0x8000) {
        eyeX -= forwardX * camSpeed;
        eyeY -= forwardY * camSpeed;
        eyeZ -= forwardZ * camSpeed;
        centerX -= forwardX * camSpeed;
        centerY -= forwardY * camSpeed;
        centerZ -= forwardZ * camSpeed;
    }
    if (GetAsyncKeyState('A') & 0x8000) {
        eyeX += rightX * camSpeed;
        eyeZ += rightZ * camSpeed;
        centerX += rightX * camSpeed;
        centerZ += rightZ * camSpeed;
    }
    if (GetAsyncKeyState('D') & 0x8000) {
        eyeX -= rightX * camSpeed;
        eyeZ -= rightZ * camSpeed;
        centerX -= rightX * camSpeed;
        centerZ -= rightZ * camSpeed;
    }
    // Up/down
    if (GetAsyncKeyState(VK_SPACE) & 0x8000) {
        eyeY += camSpeed;
        centerY += camSpeed;
    }
    if (GetAsyncKeyState(VK_SHIFT) & 0x8000) {
        eyeY -= camSpeed;
        centerY -= camSpeed;
    }
}

void DrawAllShapes() {
    for (const auto& shape : hz::shapes)
        if (shape.visible)
            shape.Draw();
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int) {
    const char* CLASS_NAME = "HorizonsEngineClass";

    WNDCLASS wc = { };
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.style = CS_OWNDC; // Important for OpenGL

    RegisterClass(&wc);

    // Create fullscreen window
    HWND hwnd = CreateWindowEx(
        WS_EX_APPWINDOW,
        CLASS_NAME,
        "Horizons Engine",
        WS_POPUP | WS_VISIBLE,
        0, 0, windowWidth, windowHeight,
        NULL, NULL, hInstance, NULL);

    if (!hwnd) {
        MessageBox(NULL, "Failed to create window.", "Error", MB_OK);
        return -1;
    }

    // Get device context and set pixel format
    HDC hdc = GetDC(hwnd);
    SetupPixelFormat(hdc);

    // Create and enable OpenGL rendering context
    HGLRC hglrc = wglCreateContext(hdc);
    if (!hglrc) {
        MessageBox(NULL, "Failed to create OpenGL context.", "Error", MB_OK);
        return -1;
    }
    if (!wglMakeCurrent(hdc, hglrc)) {
        MessageBox(NULL, "Failed to activate OpenGL context.", "Error", MB_OK);
        return -1;
    }

    // ENABLE VSYNC HERE
    typedef BOOL(WINAPI* PFNWGLSWAPINTERVALEXTPROC)(int interval);
    PFNWGLSWAPINTERVALEXTPROC wglSwapIntervalEXT = nullptr;
    wglSwapIntervalEXT = (PFNWGLSWAPINTERVALEXTPROC)wglGetProcAddress("wglSwapIntervalEXT");
    if (wglSwapIntervalEXT) {
        wglSwapIntervalEXT(1);
    }
    else {
        MessageBox(NULL, "VSync not supported.", "Warning", MB_OK);
    }

    ShowCursor(FALSE);
    SetCapture(hwnd);

    ShowWindow(hwnd, SW_SHOW);
    SetForegroundWindow(hwnd);
    SetFocus(hwnd);

    POINT centerPos = { windowWidth / 2, windowHeight / 2 };
    ClientToScreen(hwnd, &centerPos);  // Convert client coords to screen coords for SetCursorPos
    SetCursorPos(centerPos.x, centerPos.y);

    InitScene();
    InitCrosshair();

    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);  // Default depth test function

    InitFrame();  // Initialize frame timing ONCE before the loop

    // Main loop
    MSG msg = { };
    bool running = true;
    while (running) {
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) running = false;
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        // ---------------------------------------------------------------------------
        //  Input:  detect a *new* left-click (button went up→down this frame)
        // ---------------------------------------------------------------------------
        bool lmbDownNow = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
        if (lmbDownNow && !lmbWasDown)            // edge: just clicked
        {
            // Get mouse position in client coords
            POINT p; GetCursorPos(&p); ScreenToClient(hwnd, &p);

            //  Convert to picking ray
            hz::Ray ray = hz::ScreenToRay(p.x, p.y, windowWidth, windowHeight);

            // Try to select the closest shape; sets hz::selectedShapeIndex
            hz::TrySelectShape(ray);
        }
        lmbWasDown = lmbDownNow;     // keep for next frame

        // Clear screen
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Setup projection
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(45.0, aspectRatio, 0.1, 100.0);

        // Setup camera view
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        gluLookAt(eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ);

        bool isNPressed = (GetAsyncKeyState('N') & 0x8000) != 0;

        if (isNPressed && !wasNPressed) {
            // Calculate forward vector from camera yaw and pitch
            float yawRad = cameraYaw * 3.14159265f / 180.0f;
            float pitchRad = cameraPitch * 3.14159265f / 180.0f;

            float forwardX = cosf(pitchRad) * cosf(yawRad);
            float forwardY = sinf(pitchRad);
            float forwardZ = cosf(pitchRad) * sinf(yawRad);

            // Normalize forward vector
            float length = std::sqrt(forwardX * forwardX + forwardY * forwardY + forwardZ * forwardZ);
            if (length != 0.0f) {
                forwardX /= length;
                forwardY /= length;
                forwardZ /= length;
            }

            // Spawn shape 5 units in front of camera eye position
            float spawnX = eyeX + forwardX * 5.0f;
            float spawnY = eyeY + forwardY * 5.0f;
            float spawnZ = eyeZ + forwardZ * 5.0f;

            hz::AddShape(hz::SHAPE_CUBE, spawnX, spawnY, spawnZ, 0, 0, 0, 1.0f, 0.5f, 0.5f, 0.5f);
        }

        wasNPressed = isNPressed; // update for next frame

        // Update camera position using delta time
        UpdateMouseLook(hwnd);
        UpdateCameraPosition();

        // Draw all shapes
        hz::UpdateSelectedMovement();
        hz::UpdateSelectedRotation();
        hz::UpdateSelectedScale();

        hz::UpdateSelectedColorCycle();

        DrawAllShapes();
        hz::DrawSelectionOutline();  // outline (only if something is selected)

        DrawCrosshair(windowWidth, windowHeight);

        // Swap buffers first to avoid stalls
        SwapBuffers(hdc);

        // Frame limiting after rendering to maintain steady FPS
        LimitFrame(60.0f);
    }

    // Cleanup
    wglMakeCurrent(NULL, NULL);
    wglDeleteContext(hglrc);
    ReleaseDC(hwnd, hdc);
    DestroyWindow(hwnd);

    return 0;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    case WM_CLOSE:
        PostQuitMessage(0);
        return 0;
    case WM_KEYDOWN:
        if (wParam == VK_ESCAPE) {
            PostQuitMessage(0);
            return 0;
        }
        break;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}
