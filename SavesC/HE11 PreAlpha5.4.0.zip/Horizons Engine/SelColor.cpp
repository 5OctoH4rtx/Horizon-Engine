//set shape color
// SelColor.cpp
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "ShapeX.h"
#include "Select.h"
#include "SelColor.h"

namespace hz {

    struct ColorRGB { float r, g, b; };

    static const ColorRGB colorCycle[] = {
        {1.0f, 1.0f, 1.0f},  // white
        {0.5f, 0.5f, 0.5f},  // grey
        {0.3f, 0.3f, 0.3f},  // dark grey
        {0.0f, 0.0f, 0.0f},  // black
        {0.6f, 0.3f, 0.1f},  // brown
        {0.8f, 0.6f, 0.4f},  // tan
        {1.0f, 0.0f, 0.0f},  // red
        {0.5f, 0.0f, 0.0f},  // maroon
        {0.3f, 0.0f, 0.0f},  // dark red
        {1.0f, 0.5f, 0.0f},  // orange
        {1.0f, 1.0f, 0.0f},  // yellow
        {1.0f, 0.84f, 0.0f}, // gold
        {0.0f, 1.0f, 0.0f},  // green
        {0.0f, 0.5f, 0.0f},  // dark green
        {0.5f, 0.5f, 0.0f},  // olive
        {0.0f, 0.5f, 0.5f},  // teal
        {0.0f, 1.0f, 1.0f},  // cyan
        {0.6f, 0.8f, 1.0f},  // light blue
        {0.0f, 0.0f, 1.0f},  // blue
        {0.0f, 0.0f, 0.5f},  // navy
        {0.7f, 0.6f, 1.0f},  // light purple
        {0.5f, 0.0f, 0.5f},  // purple
        {1.0f, 0.0f, 1.0f},  // magenta
        {1.0f, 0.75f, 0.8f}  // pink
    };

    static int colorIndex = 1; // Start at index 1 (grey)

    void UpdateSelectedColorCycle() {
        if (selectedShapeIndex < 0 || selectedShapeIndex >= (int)shapes.size()) return;

        static bool leftPressedLast = false;
        static bool rightPressedLast = false;

        bool leftPressed = (GetAsyncKeyState(VK_OEM_4) & 0x8000); // '['
        bool rightPressed = (GetAsyncKeyState(VK_OEM_6) & 0x8000); // ']'

        if (leftPressed && !leftPressedLast) {
            colorIndex = (colorIndex - 1 + (int)std::size(colorCycle)) % (int)std::size(colorCycle);
            const auto& col = colorCycle[colorIndex];
            shapes[selectedShapeIndex].r = col.r;
            shapes[selectedShapeIndex].g = col.g;
            shapes[selectedShapeIndex].b = col.b;
        }
        if (rightPressed && !rightPressedLast) {
            colorIndex = (colorIndex + 1) % (int)std::size(colorCycle);
            const auto& col = colorCycle[colorIndex];
            shapes[selectedShapeIndex].r = col.r;
            shapes[selectedShapeIndex].g = col.g;
            shapes[selectedShapeIndex].b = col.b;
        }

        leftPressedLast = leftPressed;
        rightPressedLast = rightPressed;
    }

} // namespace hz