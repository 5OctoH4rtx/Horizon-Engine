#pragma once
#include "ShapeX.h"     // shapes vector + ShapeInstance
#include "Select.h"     // selectedShapeIndex

namespace hz {

    // Call once per frame to check for [ and ] key presses and cycle selected shape color
    void UpdateSelectedColorCycle();

}