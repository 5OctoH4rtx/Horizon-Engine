#pragma once

namespace hz {
    void DrawColorSplot(int screenWidth, int screenHeight);
}
