#pragma once

extern float eyeX, eyeY, eyeZ;
extern float centerX, centerY, centerZ;
extern float upX, upY, upZ;

// --- Test texture billboard state ---
extern bool showTestTexture;
extern float testTexPosX, testTexPosY, testTexPosZ;