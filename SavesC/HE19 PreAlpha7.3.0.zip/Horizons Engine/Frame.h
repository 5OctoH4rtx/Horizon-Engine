// Frame.h
#pragma once

void InitFrame();
void LimitFrame(float targetFPS = 60.0f);
float GetDeltaTime();