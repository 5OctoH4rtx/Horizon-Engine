#pragma once

void InitCrosshair();
void DrawCrosshair(int screenWidth, int screenHeight);